# smoker.entry.web — Manual-payment backend starter (v0.3)

This version replaces automatic blockchain detection and automatic withdrawals with a **manual USDT payment review workflow**. No private keys, seed phrases, blockchain signer, auto-withdrawal, or automatic payment watcher are used.

## Included
- Storefront catalog and checkout with five network choices: TRC20, BEP20, ERC20, Polygon, Arbitrum.
- Admin-configurable receiving wallet for each network.
- Buyer submits TXID + payment screenshot (JPG/PNG/WEBP, max 5 MB).
- Order status: pending → submitted → paid or rejected.
- Admin dashboard to inspect proof, approve/reject, and add a review note.
- Ebook download access is generated only after admin approval.
- Private order-specific customer/admin message thread.
- PDF ebooks and payment proofs stored outside the public directory.

## Important before taking real payments
1. Create a Supabase project. In Project Settings → Database, copy the PostgreSQL connection string. Use a server-side connection string only; never put it in browser JavaScript.
2. Deploy this Node.js app to a persistent Node host with HTTPS and persistent disk storage. The current starter stores PDF books and payment screenshots on local disk; do not deploy it to an ephemeral/serverless filesystem without first moving those files to private object storage (for example, a private Supabase Storage bucket).
3. Set `DATABASE_URL`, a long random `ADMIN_API_TOKEN`, `PUBLIC_BASE_URL`, and `CORS_ORIGIN` in the host's secret environment variables. Do not commit `.env`.
4. Run `sql/schema.sql` once, then run `sql/manual-payments-migration.sql` against the same Supabase database.
5. Deploy the app, open `/admin.html`, log in with the admin token, add and verify the receiving wallet addresses for each network you intend to accept. Do not enable a network until its wallet address is confirmed.
6. Upload the ebook PDFs from the admin dashboard, then test with a zero-value/test workflow before accepting customer funds.

## Local setup
Requires Node.js 20+ and PostgreSQL.

```bash
cp .env.example .env
# Edit .env with your database URL and a long random admin token
npm install
psql "$DATABASE_URL" -f sql/schema.sql
psql "$DATABASE_URL" -f sql/manual-payments-migration.sql
npm run dev
```
Open `http://localhost:3000/` for the store and `http://localhost:3000/admin.html` for admin.

## Manual customer flow
1. Buyer chooses ebook, email, and exact USDT network.
2. Server creates order using the active wallet configured for that network.
3. Buyer sends exact USDT amount and submits TXID + screenshot.
4. Admin independently verifies network, receiving address, amount, TXID, and confirmations in a trusted wallet/block explorer.
5. Admin approves or rejects. Approval creates a protected download link; rejection requires a note.

**Never approve based only on a screenshot.** Verify the transaction independently on the correct network. Transfers are irreversible. A wrong-network transfer may be unrecoverable.

## Admin API
All `/api/admin/*` endpoints require `Authorization: Bearer <ADMIN_API_TOKEN>`.
- `GET /api/admin/summary`
- `GET /api/admin/orders`
- `POST /api/admin/payment-wallets` `{ "network":"TRC20", "address":"..." }`
- `GET /api/admin/payment-wallets`
- `PATCH /api/admin/payment-wallets/:id` `{ "active": false }`
- `POST /api/admin/orders/:id/approve`
- `POST /api/admin/orders/:id/reject` `{ "note":"..." }`
- `GET/POST /api/admin/orders/:id/messages`

Customer endpoints use order UUID + matching email. Keep order IDs private. For production scale, add customer authentication, rate limiting, malware scanning for uploads, audit logs, alerting, backups, and move file storage to private object storage. The simple admin bearer-token login is an initial private admin gate, not MFA.

## Not included / deliberately disabled
- No automatic on-chain payment watcher.
- No automatic withdrawal or Indodax payout.
- No private-key storage or signing.
- No guarantee of legal/tax compliance; confirm applicable rules before selling internationally.
