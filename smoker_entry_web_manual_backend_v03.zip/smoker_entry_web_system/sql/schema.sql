CREATE TABLE IF NOT EXISTS products (
  id BIGSERIAL PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'E-book',
  description TEXT NOT NULL DEFAULT '',
  price_usdt NUMERIC(18,6) NOT NULL CHECK (price_usdt > 0),
  image_url TEXT NOT NULL DEFAULT '',
  ebook_file TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS deposit_addresses (
  id BIGSERIAL PRIMARY KEY,
  address TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'available'
    CHECK (status IN ('available','assigned','retired')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(id),
  customer_email TEXT NOT NULL,
  expected_amount NUMERIC(18,6) NOT NULL,
  deposit_address TEXT NOT NULL REFERENCES deposit_addresses(address),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','paid','expired','cancelled','underpaid','overpaid')),
  expires_at TIMESTAMPTZ NOT NULL,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payments (
  id BIGSERIAL PRIMARY KEY,
  order_id UUID NOT NULL UNIQUE REFERENCES orders(id),
  txid TEXT NOT NULL UNIQUE,
  from_address TEXT,
  to_address TEXT NOT NULL,
  amount_usdt NUMERIC(18,6) NOT NULL,
  block_timestamp TIMESTAMPTZ,
  confirmed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id BIGSERIAL PRIMARY KEY,
  entry_type TEXT NOT NULL CHECK (entry_type IN ('sale_credit','withdrawal_reserve','withdrawal_release','withdrawal_debit')),
  reference TEXT NOT NULL,
  amount_usdt NUMERIC(18,6) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(entry_type, reference)
);

CREATE TABLE IF NOT EXISTS download_tokens (
  id BIGSERIAL PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES orders(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  max_downloads INTEGER NOT NULL DEFAULT 3,
  download_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id UUID PRIMARY KEY,
  amount_usdt NUMERIC(18,6) NOT NULL CHECK (amount_usdt > 0),
  destination_address TEXT NOT NULL,
  network TEXT NOT NULL DEFAULT 'TRC20',
  status TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','processing','sent','failed','cancelled')),
  txid TEXT UNIQUE,
  source TEXT NOT NULL CHECK (source IN ('manual','automatic')),
  failure_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS system_jobs (
  job_key TEXT PRIMARY KEY,
  last_run_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_expiry ON orders(expires_at);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status);
