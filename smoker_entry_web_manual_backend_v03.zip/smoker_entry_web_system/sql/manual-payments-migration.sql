-- Run AFTER schema.sql. Manual payment workflow for smoker.entry.web.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS network TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_proof TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS submitted_txid TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_submitted_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS review_note TEXT;
ALTER TABLE orders ALTER COLUMN deposit_address DROP NOT NULL;
ALTER TABLE orders ALTER COLUMN expires_at DROP NOT NULL;
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check CHECK (status IN ('pending','submitted','paid','rejected','expired','cancelled','underpaid','overpaid'));
CREATE TABLE IF NOT EXISTS payment_wallets (
 id BIGSERIAL PRIMARY KEY,
 network TEXT NOT NULL CHECK (network IN ('TRC20','BEP20','ERC20','POLYGON','ARBITRUM')),
 address TEXT NOT NULL,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 UNIQUE(network,address)
);
CREATE TABLE IF NOT EXISTS order_messages (
 id BIGSERIAL PRIMARY KEY,
 order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 sender TEXT NOT NULL CHECK (sender IN ('customer','admin')),
 message TEXT NOT NULL CHECK (length(message) BETWEEN 1 AND 2000),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_orders_manual_status ON orders(status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_order_messages_order ON order_messages(order_id,id);
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_deposit_address_fkey;
